/*
  霞ヶ原駐屯地サイト 編集用データ
  基本的にこのファイルだけ編集すれば内容を変更できます。

  GitHub Pages対応:
  画像は ./images/ファイル名 の相対パスで指定してください。
*/

const SITE_DATA = {
  siteName: "霞ヶ原駐屯地",
  siteNameEn: "KASUMIGAHARA GARRISON",

  links: {
    game: "https://www.roblox.com/",
    robloxGroup: "https://www.roblox.com/",
    discord: "#"
  },

  images: {
    logo: "./images/logo.png",
    header: "./images/header.jpg",
    hero: "./images/hero.jpg"
  },

  hero: {
    title: "秩序を守り、<br>任務を遂行する。",
    description:
      "霞ヶ原駐屯地は、規律、連携、役割分担を重視した<br>Roblox上の駐屯地ロールプレイコミュニティです。"
  },

  about: [
    "霞ヶ原駐屯地は、隊員同士の連携と規律ある行動を重視し、訓練・警備・航空運用などの活動を行うRoblox上の駐屯地ロールプレイコミュニティです。",
    "初めて参加する方にも分かりやすい教育体制を整え、役職や所属部隊に応じた任務を通じて、組織として活動する楽しさを体験できる環境を目指しています。"
  ],

  units: [
    {
      name: "警務隊",
      english: "MILITARY POLICE UNIT",
      image: "./images/unit-keimu.jpg",
      description:
        "警務隊は、霞ヶ原駐屯地内の秩序維持を担う専門部隊です。施設警備、巡察、規則違反への対応、事件・事故発生時の初動対応などを行い、隊員が安全かつ規律正しく活動できる環境を維持します。冷静な判断力と公平な対応が求められる部隊です。"
    },
    {
      name: "教育隊",
      english: "TRAINING UNIT",
      image: "./images/unit-kyoiku.jpg",
      description:
        "教育隊は、新規入隊者や候補生に対する基礎教育を担当します。基本教練、服務、敬礼、無線通信、装備の取扱い、部隊行動などを段階的に指導し、任務に必要な知識と規律を身につけた隊員を育成します。駐屯地の将来を支える人材育成の中核となる部隊です。"
    },
    {
      name: "航空隊",
      english: "AVIATION UNIT",
      image: "./images/unit-koku.jpg",
      description:
        "航空隊は、航空機を使用した輸送、偵察、救難支援および部隊展開を担当する専門部隊です。地上部隊や司令部と連携し、上空から任務全体を支援します。安全な航空運用を最優先とし、高い操縦技術と状況判断能力を備えた隊員によって構成されます。"
    },
    {
      name: "統合幕僚司令部",
      english: "JOINT STAFF HEADQUARTERS",
      image: "./images/unit-headquarters.jpg",
      description:
        "統合幕僚司令部は、霞ヶ原駐屯地全体の運営方針を策定し、各部隊を統括する運営機関です。人事、規則整備、昇任管理、訓練計画、イベント運営、広報、開発調整などを担当し、各部隊が円滑に活動できる環境を整備します。公平性と継続性を重視し、駐屯地全体の発展を支えます。"
    }
  ],

  development: [
    {
      title: "駐屯地マップ拡張",
      progress: 72,
      image: "./images/dev-map.jpg",
      description: "新施設、訓練区域、警備区画の追加および既存エリアの調整を進めています。"
    },
    {
      title: "航空運用システム",
      progress: 48,
      image: "./images/dev-aircraft.jpg",
      description: "航空機の操作性、搭乗処理、管制連携を含むシステムを開発しています。"
    },
    {
      title: "隊員情報UI",
      progress: 86,
      image: "./images/dev-ui.jpg",
      description: "階級、所属部隊、勤務状態を分かりやすく表示するUIを更新しています。"
    },
    {
      title: "制服・装備更新",
      progress: 35,
      image: "./images/dev-uniform.jpg",
      description: "所属部隊や役職に合わせた制服、装備、識別表示を制作しています。"
    }
  ],

  announcements: [
    {
      date: "2026-07-17",
      category: "募集",
      title: "候補生募集および入隊教育について"
    },
    {
      date: "2026-07-12",
      category: "開発",
      title: "駐屯地マップの更新作業を開始しました"
    },
    {
      date: "2026-07-05",
      category: "運営",
      title: "服務規則および部隊運用方針を更新しました"
    }
  ],

  topics: [
    {
      date: "2026-07-16",
      category: "訓練",
      title: "教育隊による候補生基礎訓練",
      description: "候補生を対象とした基本教練および服務教育を実施しました。",
      image: "./images/topic-training.jpg"
    },
    {
      date: "2026-07-11",
      category: "開発",
      title: "航空隊施設の開発状況",
      description: "格納庫および航空運用区域の制作を進めています。",
      image: "./images/topic-aviation.jpg"
    },
    {
      date: "2026-07-03",
      category: "広報",
      title: "霞ヶ原駐屯地公式サイトを公開",
      description: "活動情報や開発状況を発信する公式サイトを公開しました。",
      image: "./images/topic-website.jpg"
    }
  ]
};
